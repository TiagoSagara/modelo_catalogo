enum ListBottomAppBar {
  categorias("Categorias"),
  produtos("Produtos"),
  promocoes("Promoções");

  final String name;

  const ListBottomAppBar(this.name);
}
