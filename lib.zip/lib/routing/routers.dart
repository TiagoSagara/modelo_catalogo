class AppRouters {
  static const String home = '/';
  static const String productList = '/produtos';
  static const String productDetail = '/detalhes';
  static const String productGroup = '/category';
  static const String salePage = '/sale';
}
