import 'package:flutter/material.dart';

Widget buildPlaceholder() {
  return Container(
    height: 200,
    width: 200,
    color: Colors.grey[200],
    child: Icon(Icons.inventory_2, size: 50, color: Colors.grey[500]),
  );
}
