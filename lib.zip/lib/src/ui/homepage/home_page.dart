import 'package:api_produtos/src/ui/homepage/widgets/lista_produtos_view_model.dart';
import 'package:api_produtos/src/ui/homepage/widgets/custom_appbar.dart';
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: CustomAppBar(),
        body: ListaProdutosViewModel().body(),
      ),
    );
  }
}
