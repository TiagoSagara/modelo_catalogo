import 'package:api_produtos/routing/router.dart';
import 'package:api_produtos/src/ui/core/custom_buttons.dart';
import 'package:flutter/material.dart';

class ListaProdutosViewModel {
  get context => null;

  Widget body() {
    return Center(
      child: Card(
        elevation: 10,
        child: SizedBox(
          height: 250,
          width: 350,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              CustomButtons.textButton(
                text: 'Listar todos os produtos',
                onPressed: () {
                  context.push(AppRouter.productList);
                },
              ),
              Divider(
                color: Colors.blueGrey,
                thickness: 1,
                indent: 30,
                endIndent: 30,
              ),
              CustomButtons.textButton(
                text: 'Listar produto por ID',
                onPressed: () {},
              ),
            ],
          ),
        ),
      ),
    );
  }
}
