import 'package:api_produtos/dependences/service_locator.dart';
import 'package:api_produtos/routing/routers.dart';
import 'package:api_produtos/src/ui/core/components/custom_appbar.dart';
import 'package:api_produtos/src/ui/core/components/product_card.dart';
import 'package:api_produtos/src/ui/search/products/view_model/product_bloc.dart';
import 'package:api_produtos/src/ui/search/products/view_model/list_search_view_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

class CategoriesListPage extends StatelessWidget {
  final String? categorySlug;
  const CategoriesListPage({super.key, this.categorySlug});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) {
        final bloc = getIt<ProductBloc>();
        if (categorySlug != null && categorySlug!.isNotEmpty) {
          bloc.loadProducts(categorySlug!, isCategory: true);
        } else {
          bloc.loadProducts('', isCategory: false);
        }
        return bloc;
      },
      child: Builder(
        builder: (newContext) {
          return Scaffold(
            appBar: CustomAppbar(onItemSelected: (id) {}),
            body: Column(
              children: [
                if (categorySlug != null)
                  Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Categoria: ${categorySlug!.toUpperCase()}',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Colors.blueGrey,
                        ),
                      ),
                    ),
                  ),
                // ✅ FIX 3: usa ProductBloc/ProductState para exibir produtos
                Expanded(
                  child: BlocBuilder<ProductBloc, ProductState>(
                    builder: (context, state) {
                      if (state is ProductLoading) {
                        return const Center(child: CircularProgressIndicator());
                      }
                      if (state is ProductError) {
                        return Center(child: Text(state.message));
                      }
                      if (state is ProductLoaded) {
                        if (state.products.isEmpty) {
                          return const Center(
                            child: Text('Nenhum produto encontrado.'),
                          );
                        }
                        return _buildProductGrid(context, state.products);
                      }
                      return const SizedBox.shrink();
                    },
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildProductGrid(BuildContext context, List products) {
    return LayoutBuilder(
      builder: (context, constraints) {
        int crossAxisCount = constraints.maxWidth >= 1100
            ? 4
            : (constraints.maxWidth >= 700 ? 3 : 2);

        return Center(
          child: Container(
            constraints: const BoxConstraints(maxWidth: 1100),
            child: GridView.builder(
              padding: const EdgeInsets.all(10),
              itemCount: products.length,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: crossAxisCount,
                mainAxisSpacing: 10,
                crossAxisSpacing: 10,
                childAspectRatio: crossAxisCount == 2 ? 0.6 : 0.8,
              ),
              itemBuilder: (context, index) {
                final product = products[index];
                return InkWell(
                  onTap: () =>
                      context.push(AppRouters.productDetail, extra: product),
                  child: CardSearch(product: product),
                );
              },
            ),
          ),
        );
      },
    );
  }
}
