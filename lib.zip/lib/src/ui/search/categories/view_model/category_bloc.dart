import 'package:api_produtos/data/repositories/categories_repository.dart';
import 'package:api_produtos/domain/models/categories_bottom_appbar_bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class CategoryBloc extends Cubit<CategoryState> {
  final CategoriesRepository _repository;

  CategoryBloc(this._repository) : super(CategoryInitial());

  Future<void> fetchCategories() async {
    emit(CategoryLoading());
    try {
      final categoriesModels = await _repository.getCategories();
      final List<String> categoriesStrings = categoriesModels
          .map((e) => e.name)
          .toList();
      emit(CategoryLoaded(categoriesStrings));
    } catch (e) {
      emit(CategoryError("Erro ao carregar categorias"));
    }
  }
}
