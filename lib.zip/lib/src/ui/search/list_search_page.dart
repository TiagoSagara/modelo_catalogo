import 'package:api_produtos/src/ui/homepage/widgets/custom_appbar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:api_produtos/dependences/service_locator.dart';
import 'view_model/product_bloc.dart';
import 'view_model/list_search_view_model.dart';

class ListSearchPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => ProductBloc(getIt())..loadProducts(),
      child: Scaffold(
        appBar: CustomAppBar(),
        body: BlocBuilder<ProductBloc, ProductState>(
          builder: (context, state) {
            if (state is ProductLoading)
              return Center(child: CircularProgressIndicator());
            if (state is ProductError)
              return Center(child: Text(state.message));
            if (state is ProductLoaded) {
              return ListView.builder(
                itemCount: state.products.length,
                itemBuilder: (context, index) {
                  final product = state.products[index];
                  return ListTile(
                    leading: Image.network(product.thumbnail, width: 50),
                    title: Text(product.title),
                    subtitle: Text("R\$ ${product.price}"),
                  );
                },
              );
            }
            return Container();
          },
        ),
      ),
    );
  }
}
