abstract final class ImageList {
  static const logoMultSistem = "assets/images/logo.png";
  static const carouselAzul = "assets/images/carrossel_azul.png";
  static const carouselBolha = "assets/images/carrossel_bolha.png";
  static const carouselBoliche = "assets/images/carrossel_boliche.png";
}
