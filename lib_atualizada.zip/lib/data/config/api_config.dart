class ApiConfig {
  static const String baseUrl = 'https://api-loja-virtual.multsistem.com.br';

  /// Credenciais Basic Auth para gerar o JWT (POST /auth/token)
  static const String basicAuthUser = 'usuario';
  static const String basicAuthPassword = 'senha';

  /// Slug do tenant (informado no body de /auth/token)
  static const String slug = 'demo';
}
